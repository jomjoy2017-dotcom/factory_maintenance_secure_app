<?php
require_once 'functions.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    try {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([trim($_POST['username'])]);
        $user = $stmt->fetch();

        if ($user && password_verify($_POST['password'], $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
            logError("Failed login attempt for username: " . trim($_POST['username']));
        }
    } catch (PDOException $e) {
        logError("Login Error: " . $e->getMessage());
        $error = 'An error occurred during login.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Factory Maintenance</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2><?php echo h(__('login')); ?></h2>
        <?php if(!empty($error)) echo '<div class="alert alert-danger">'.h($error).'</div>'; ?>
        <form method="POST" class="form-card">
            <input type="hidden" name="csrf_token" value="<?php echo h(generateCsrfToken()); ?>">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn btn-primary"><?php echo h(__('login')); ?></button>
        </form>
        <p style="text-align:center;"><a href="register.php">Register New Account</a></p>
    </div>
</body>
</html>