<?php
require_once 'functions.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (strlen($username) < 4 || strlen($password) < 6) {
        $error = "Username must be at least 4 chars and password 6 chars.";
    } else {
        try {
            $check = $pdo->prepare('SELECT id FROM users WHERE username = ?');
            $check->execute([$username]);
            if ($check->fetch()) {
                $error = "Username is already taken.";
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('INSERT INTO users (username, password, role) VALUES (?, ?, "user")');
                if ($stmt->execute([$username, $hash])) {
                    header('Location: login.php');
                    exit;
                }
            }
        } catch (PDOException $e) {
            logError("Registration Error: " . $e->getMessage());
            $error = 'An error occurred during registration.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Factory Maintenance</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <?php if(!empty($error)) echo '<div class="alert alert-danger">'.h($error).'</div>'; ?>
        <form method="POST" class="form-card">
            <input type="hidden" name="csrf_token" value="<?php echo h(generateCsrfToken()); ?>">
            <input type="text" name="username" placeholder="Username (min 4 chars)" required>
            <input type="password" name="password" placeholder="Password (min 6 chars)" required>
            <button type="submit" class="btn btn-primary">Register</button>
        </form>
        <p style="text-align:center;"><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>