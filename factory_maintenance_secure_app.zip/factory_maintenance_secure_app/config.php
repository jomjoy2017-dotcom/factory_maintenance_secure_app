<?php
date_default_timezone_set('Asia/Bangkok');

ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
// Uncomment next line if using HTTPS
// ini_set('session.cookie_secure', 1);

session_start();

define('BASE_DIR', __DIR__);

$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$scriptDir = preg_replace('/\/admin$/', '', $scriptDir);
define('BASE_URL', rtrim($scriptDir, '/') . '/');

$log_dir = BASE_DIR . '/logs';
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0700, true);
    file_put_contents($log_dir . '/.htaccess', "Deny from all");
    file_put_contents($log_dir . '/index.php', "<?php http_response_code(403); exit('Forbidden'); ?>");
}
define('LOG_FILE', $log_dir . '/system_errors.log');

function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, LOG_FILE);
}

$host = 'localhost';
$db = 'factory_maintenance';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    logError("DB Connection Error: " . $e->getMessage());
    die("A system error occurred. Please try again later.");
}
?>