<?php
require_once 'config.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}

function h($string) {
    return htmlspecialchars((string)$string, ENT_QUOTES, 'UTF-8');
}

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        logError("CSRF Validation Failed for User IP: " . $_SERVER['REMOTE_ADDR']);
        die("Security validation failed (CSRF Token mismatch).");
    }
}

$lang_dict = [
    'en' => ['login' => 'Login', 'req' => 'Report Problem', 'status' => 'Status', 'save' => 'Save', 'print' => 'Print PDF', 'logout' => 'Logout', 'back' => 'Back', 'dashboard' => 'Dashboard'],
    'th' => ['login' => 'เข้าสู่ระบบ', 'req' => 'แจ้งซ่อม', 'status' => 'สถานะ', 'save' => 'บันทึก', 'print' => 'พิมพ์ PDF', 'logout' => 'ออกจากระบบ', 'back' => 'กลับ', 'dashboard' => 'แผงควบคุม'],
    'jp' => ['login' => 'ログイン', 'req' => '修理依頼', 'status' => 'ステータス', 'save' => '保存', 'print' => 'PDF印刷', 'logout' => 'ログアウト', 'back' => '戻る', 'dashboard' => 'ダッシュボード'],
    'cn' => ['login' => '登录', 'req' => '维修请求', 'status' => '状态', 'save' => '保存', 'print' => '打印 PDF', 'logout' => '登出', 'back' => '返回', 'dashboard' => '仪表板']
];

if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $lang_dict)) {
    $_SESSION['lang'] = $_GET['lang'];
}
$current_lang = $_SESSION['lang'] ?? 'th';

function __($key) {
    global $lang_dict, $current_lang;
    return $lang_dict[$current_lang][$key] ?? $key;
}
?>