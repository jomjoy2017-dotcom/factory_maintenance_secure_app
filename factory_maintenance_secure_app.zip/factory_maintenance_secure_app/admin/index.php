<?php
require_once '../functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    
    $allowed_statuses = ['pending', 'in_progress', 'completed'];
    $new_status = $_POST['status'] ?? '';
    $req_id = $_POST['req_id'] ?? 0;

    if (in_array($new_status, $allowed_statuses)) {
        try {
            $stmt = $pdo->prepare('UPDATE requests SET status = ? WHERE id = ?');
            $stmt->execute([$new_status, $req_id]);
            $_SESSION['msg'] = "Status updated successfully.";
        } catch (PDOException $e) {
            logError("Admin Update Status Error: " . $e->getMessage());
            $_SESSION['msg'] = "Error updating database status.";
        }
    } else {
        $_SESSION['msg'] = "Invalid status parameter detected.";
        logError("Mass assignment / Invalid status attempt. Data: " . $new_status);
    }
    
    $redirect_url = 'index.php?filter=' . urlencode($_GET['filter'] ?? 'all');
    header('Location: ' . $redirect_url);
    exit;
}

$filter = $_GET['filter'] ?? 'all';
$query = 'SELECT r.*, u.username FROM requests r JOIN users u ON r.user_id = u.id';
$params = [];

if ($filter === 'daily') {
    $query .= ' WHERE DATE(r.created_at) = CURDATE()';
} elseif ($filter === 'monthly') {
    $query .= ' WHERE MONTH(r.created_at) = MONTH(CURDATE()) AND YEAR(r.created_at) = YEAR(CURDATE())';
} elseif ($filter === 'yearly') {
    $query .= ' WHERE YEAR(r.created_at) = YEAR(CURDATE())';
}
$query .= ' ORDER BY r.id DESC';

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    logError("Admin Fetch Error: " . $e->getMessage());
    $requests = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Admin Dashboard</h2>
            <button onclick="window.print()" class="btn btn-secondary"><?php echo h(__('print')); ?></button>
        </div>

        <?php if(isset($_SESSION['msg'])): ?>
            <div class="alert <?php echo strpos($_SESSION['msg'], 'Error') === false && strpos($_SESSION['msg'], 'Invalid') === false ? 'alert-success' : 'alert-danger'; ?>">
                <?php echo h($_SESSION['msg']); unset($_SESSION['msg']); ?>
            </div>
        <?php endif; ?>

        <div class="filter-bar">
            <a href="?filter=all" class="btn <?php echo $filter==='all'?'active':''; ?>">All</a>
            <a href="?filter=daily" class="btn <?php echo $filter==='daily'?'active':''; ?>">Daily</a>
            <a href="?filter=monthly" class="btn <?php echo $filter==='monthly'?'active':''; ?>">Monthly</a>
            <a href="?filter=yearly" class="btn <?php echo $filter==='yearly'?'active':''; ?>">Yearly</a>
            <a href="../index.php" class="btn btn-secondary"><?php echo h(__('back')); ?></a>
        </div>
        
        <div class="table-responsive">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>User</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php foreach($requests as $r): ?>
                <tr>
                    <td>#<?php echo h($r['id']); ?></td>
                    <td><?php echo h(date('Y-m-d', strtotime($r['created_at']))); ?></td>
                    <td><?php echo h($r['username']); ?></td>
                    <td><?php echo h($r['title']); ?></td>
                    <td><span class="status-badge status-<?php echo h($r['status']); ?>"><?php echo h(str_replace('_', ' ', $r['status'])); ?></span></td>
                    <td>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="csrf_token" value="<?php echo h(generateCsrfToken()); ?>">
                            <input type="hidden" name="req_id" value="<?php echo h($r['id']); ?>">
                            <select name="status">
                                <option value="pending" <?php echo $r['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="in_progress" <?php echo $r['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                <option value="completed" <?php echo $r['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                            <button type="submit" name="update_status" class="btn btn-small btn-primary">Update</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($requests)): ?>
                <tr><td colspan="6" style="text-align:center;">No data available.</td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</body>
</html>