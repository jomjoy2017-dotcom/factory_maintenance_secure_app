<?php
require_once 'functions.php';
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$requests = [];
try {
    $stmt = $pdo->prepare('SELECT * FROM requests WHERE user_id = ? ORDER BY id DESC');
    $stmt->execute([$_SESSION['user_id']]);
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    logError("Fetch Requests Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h(__('dashboard')); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><?php echo h(__('req')); ?></h2>
            <div class="nav-links">
                <a href="?lang=th">TH</a> | <a href="?lang=en">EN</a> | <a href="?lang=jp">JP</a> | <a href="?lang=cn">CN</a> | 
                <?php if($_SESSION['role'] === 'admin') echo '<a href="admin/index.php" class="admin-link">Admin Panel</a> | '; ?>
                <a href="logout.php"><?php echo h(__('logout')); ?></a>
            </div>
        </div>

        <?php if(isset($_SESSION['msg'])): ?>
            <div class="alert <?php echo strpos($_SESSION['msg'], 'Error') === false && strpos($_SESSION['msg'], 'Invalid') === false ? 'alert-success' : 'alert-danger'; ?>">
                <?php echo h($_SESSION['msg']); unset($_SESSION['msg']); ?>
            </div>
        <?php endif; ?>

        <div class="form-card">
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo h(generateCsrfToken()); ?>">
                <input type="text" name="title" placeholder="Problem Title" required>
                <textarea name="description" placeholder="Detailed Description" required></textarea>
                <div style="margin-bottom: 15px;">
                    <label style="font-size:14px; color:#555;">Attach Image/Video (Optional):</label>
                    <input type="file" name="media" accept=".jpg,.jpeg,.png,.gif,.mp4,.mov">
                </div>
                <button type="submit" class="btn btn-primary"><?php echo h(__('save')); ?></button>
            </form>
        </div>
        
        <hr>
        <h3>My Requests</h3>
        <div class="table-responsive">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
                <?php foreach($requests as $r): ?>
                <tr>
                    <td>#<?php echo h($r['id']); ?></td>
                    <td><?php echo h($r['title']); ?></td>
                    <td><?php echo h(date('Y-m-d H:i', strtotime($r['created_at']))); ?></td>
                    <td><span class="status-badge status-<?php echo h($r['status']); ?>"><?php echo h(str_replace('_', ' ', $r['status'])); ?></span></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($requests)): ?>
                <tr><td colspan="4" style="text-align:center;">No requests found.</td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</body>
</html>