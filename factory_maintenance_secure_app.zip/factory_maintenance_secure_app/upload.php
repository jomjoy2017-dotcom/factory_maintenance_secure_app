<?php
require_once 'functions.php';
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token'] ?? '');
    
    $title = trim($_POST['title']);
    $desc = trim($_POST['description']);
    $media_path = null;
    $media_type = null;

    if (empty($title) || empty($desc)) {
        $_SESSION['msg'] = "Error: Title and Description are required.";
        header('Location: index.php');
        exit;
    }

    if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov'];
        $file_info = pathinfo($_FILES['media']['name']);
        $ext = strtolower($file_info['extension'] ?? '');

        if (in_array($ext, $allowed_ext)) {
            $upload_dir = BASE_DIR . '/uploads';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
                // Secure upload dir for various servers
                file_put_contents($upload_dir . '/.htaccess', "<Files *>\nSetHandler none\nSetHandler default-handler\nOptions -ExecCGI -Indexes\nphp_flag engine off\n</Files>");
                file_put_contents($upload_dir . '/index.php', "<?php http_response_code(403); exit('Forbidden'); ?>");
            }

            $filename = bin2hex(random_bytes(16)) . '.' . $ext;
            $target_path = $upload_dir . '/' . $filename;

            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['media']['tmp_name']);
            finfo_close($finfo);

            $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/quicktime'];
            
            if (in_array($mime, $allowed_mimes)) {
                if (move_uploaded_file($_FILES['media']['tmp_name'], $target_path)) {
                    $media_path = 'uploads/' . $filename;
                    $media_type = $mime;
                } else {
                    $_SESSION['msg'] = "Error moving uploaded file.";
                    header('Location: index.php');
                    exit;
                }
            } else {
                $_SESSION['msg'] = "Invalid file MIME type.";
                header('Location: index.php');
                exit;
            }
        } else {
            $_SESSION['msg'] = "Invalid file extension.";
            header('Location: index.php');
            exit;
        }
    }

    try {
        $stmt = $pdo->prepare('INSERT INTO requests (user_id, title, description, media_path, media_type) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$_SESSION['user_id'], $title, $desc, $media_path, $media_type]);
        $_SESSION['msg'] = "Request submitted successfully.";
    } catch (PDOException $e) {
        logError("Upload Request Error: " . $e->getMessage());
        $_SESSION['msg'] = "A database error occurred while saving your request.";
    }

    header('Location: index.php');
    exit;
}
?>